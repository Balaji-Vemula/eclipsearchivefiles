

class Maths{
	
	
	public int z;

	int add(int x,int y)
	{
		return x+y;
	}
}




public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Maths obj1=new Maths();
		
		obj1.z=7;
		
		System.out.println(obj1.add(1, 3));
	}

}

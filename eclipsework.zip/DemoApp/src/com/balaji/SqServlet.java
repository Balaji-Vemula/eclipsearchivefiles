package com.balaji;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/sq")
public class SqServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		int k=0;
		Cookie c[]=req.getCookies();
		for(Cookie i:c)
		{
			if(i.getName().equals("k"))
			{
				k = Integer.parseInt(i.getValue());
			}
		}
		
		/*
		 * HttpSession s=req.getSession(); s.removeAttribute("k"); int
		 * k=(int)s.getAttribute("k");
		 *///used when HttpSession is used
		
		
		//int k=Integer.parseInt(req.getParameter("k")); //used when SendRedirect is used
		
		
		//int k=(int) req.getAttribute("k");//used when request Dispatcher is used
		
		
		PrintWriter out=res.getWriter();
		out.println("The Square is: "+k*k);
		//res.getWriter().println("The result is: "+k);
	}
}
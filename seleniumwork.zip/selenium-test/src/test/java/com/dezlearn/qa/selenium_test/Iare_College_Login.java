package com.dezlearn.qa.selenium_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Iare_College_Login {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		

		System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://samvidha.iare.ac.in/");
		
		
		Thread.sleep(1000);
		driver.findElement(By.id("txt_uname")).sendKeys("16951A0422");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='txt_pwd']")).sendKeys("fBPZHRk4");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@id='but_submit']")).click();
		WebDriverWait wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.urlToBe("https://cms.iare.ac.in/home"));
		driver.findElement(By.xpath("//span[contains(text(),'VEMULA BALAJI')]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[contains(text(),'Profile')]")).click();
		
		
		
		driver.quit();
		
	}

}

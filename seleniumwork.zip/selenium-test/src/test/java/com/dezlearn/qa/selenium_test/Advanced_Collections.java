package com.dezlearn.qa.selenium_test;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Advanced_Collections {

	public static void main(String[] args) {
		
		/*
		 * Example: Retrieve the titles of all the books present on 'goodreads' home page
		 */
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.goodreads.com/");
		
		List<WebElement> books = driver.findElements(By.cssSelector("img[src$='.jpg']"));
		
		System.out.println(books.size());
		
		/*
		 * for(WebElement book : books) 
		 * {
			 * System.out.println(book.isDisplayed());
			 * System.out.println(book.getAttribute("alt"));
			 * System.out.println("---------------------"); 
		* }
		 */
		List<WebElement> visible=new ArrayList<>();
		for(WebElement book : books) 
		{
			if(book.isDisplayed()) {
				visible.add(book);
			}
		}
		System.out.println("Visible images count is: "+visible.size());
		System.out.println("Invisible images count is: "+(books.size()-visible.size()));
		
		driver.quit();

	}

}

package com.dezlearn.qa.selenium_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FindElementBy_ID_and_Text {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//For Chrome
		System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//For Firefox
		//System.setProperty("webdriver.gecko.driver","A:\\Selenium_work\\geckodriver.exe");
		//WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.actitime.com");
		Thread.sleep(1000);
		driver.findElement(By.linkText("Try Free")).click();
		Thread.sleep(1000);
		WebDriverWait wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.urlToBe("https://www.actitime.com/free-online-trial"));
		
		Thread.sleep(500);
		driver.findElement(By.id("first-name")).sendKeys("Balaji");
		Thread.sleep(500);
		driver.findElement(By.id("last-name")).sendKeys("Vemula");
		Thread.sleep(500);
		driver.findElement(By.id("email")).sendKeys("vemulabalaji1998@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.id("company")).sendKeys("Trianz");
		Thread.sleep(500);
		//driver.findElement(By.id("start-trial-submit")).click();
	}

}

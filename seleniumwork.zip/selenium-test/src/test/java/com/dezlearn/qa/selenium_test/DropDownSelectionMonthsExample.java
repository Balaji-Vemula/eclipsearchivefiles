package com.dezlearn.qa.selenium_test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DropDownSelectionMonthsExample {

	public static void main(String[] args) throws InterruptedException {
		
		/*
		 * Working with Selectbox.
		 * 1. How to 'Get Currently Selected Option'?
		 * 2. How to 'Select an Option'?
		 */
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.thecalculatorsite.com/misc/birthday-calculator.php");
		
		String x = driver.findElement(By.id("birthMonth")).getAttribute("value");
		String y = driver.findElement(By.id("birthDay")).getAttribute("value");
		String z = driver.findElement(By.id("birthYear")).getAttribute("value");
		
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		
		// Taking the collection of all the months, days and year
		List<WebElement> m = driver.findElements(By.cssSelector("select#birthMonth>option"));
		List<WebElement> d = driver.findElements(By.cssSelector("select#birthDay>option"));
		List<WebElement> ye = driver.findElements(By.cssSelector("select#birthYear>option"));
		
		// selecting the month, august from the month collection
		for(WebElement month:m) 
		{
			if (month.getText().trim().equals("August")) 
			{
				month.click();
				break;
			}
		}
		
		//selecting the day, 1st from the days collection
		for(WebElement day:d) 
		{
			if (day.getText().trim().equals("1")) 
			{
				day.click();
				break;
			}
		}
		
		//selectiong the year 1998 from the year collection
		for(WebElement year:ye) 
		{
			if (year.getText().trim().equals("1998")) 
			{
				year.click();
				break;
			}
		}
		//clicking on calculate after entering all the above details ( august 1 1998)
		driver.findElement(By.cssSelector("div.calculator_form:nth-child(3) div.desktopForm:nth-child(2) form:nth-child(1) div.submitButtons:nth-child(3) > button.calculatorButton")).click();
		//driver.quit();
		
	}
}

package com.dezlearn.qa.selenium_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon_FindElementBy_Name_Class_PartialClass {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//For Chrome
		System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//For Firefox
		//System.setProperty("webdriver.gecko.driver","A:\\Selenium_work\\geckodriver.exe");
		//WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.amazon.in/");
		Thread.sleep(500);
		
		driver.findElement(By.name("field-keywords")).sendKeys("iphone 11 pro max 512gb");
		Thread.sleep(500);
		
		driver.findElement(By.xpath("//header/div[@id='navbar']/div[@id='nav-belt']/div[2]/div[1]/form[1]/div[3]/div[1]/span[1]/input[1]")).click();
		Thread.sleep(500);
		
		
		driver.findElement(By.xpath("//span[contains(text(),'Apple iPhone 11 Pro Max (512GB) - Space Grey')]")).click();
		Thread.sleep(1000);
		String product=driver.findElement(By.xpath("//span[@id='productTitle']")).getText();
		String price=driver.findElement(By.xpath("//span[@id='priceblock_ourprice']")).getText();
		
		System.out.println("Product: "+product);
		System.out.println("Price: "+price);
		
	}

}

package com.dezlearn.qa.selenium.mouseOperations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouse_Hover {

	public static void main(String[] args) throws Exception {
		
		/*
		 * Mouse hover a Menu item to populate Sub-menu
		 */

		System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.iare.ac.in/");
		
		Actions action = new Actions(driver);
		
		WebElement clients = driver.findElement(By.linkText("Departments"));
		
		action.moveToElement(clients).perform();
		
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("Electronics and Communication Engineering")).click();
		
		Thread.sleep(2000);
		
		System.out.println(driver.getCurrentUrl());

	}

}

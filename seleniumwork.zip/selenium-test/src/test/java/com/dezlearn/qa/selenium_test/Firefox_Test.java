package com.dezlearn.qa.selenium_test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Firefox_Test {
	public static void main(String[] args) {

		System.setProperty("webdriver.gecko.driver","D:\\Selenium_work\\geckodriver.exe");
		
		WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.iare.ac.in/");
		System.out.println(driver.getTitle());
		//driver.quit();
		
	}

}

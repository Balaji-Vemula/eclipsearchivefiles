package com.dezlearn.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.dezlearn.lib.AppLib;

public class AbstractBaseTest {
	WebDriver driver;
	private AppLib app;
	
	@BeforeClass(alwaysRun=true)
	public void setUp() throws Exception{
		  System.setProperty("webdriver.chrome.driver","D:\\Selenium_work\\chromedriver.exe");
		  driver= new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  app=new AppLib(driver);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() {
		driver.quit();
	}

	public AppLib App() {
		return app;
	}
	
}

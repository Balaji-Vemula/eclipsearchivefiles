package com.dezlearn.tests;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import org.testng.Assert;


public class Ebay_Home_Sanity extends AbstractBaseTest {
	
  @Test(groups= {"P0"})
  public void empty_search_test_Asserts() throws Exception{
	  
	  App().Flow().navigateToUrl(App().Pages().HomePage().getPageUrl());
	  Thread.sleep(2000);
	  
	  Assert.assertTrue(App().Pages().HomePage().isSearchButtonEnabled(), "Checking if the search button is enabled");
	  //Assert.assertFalse(homePageElements.searchBtn.isEnabled(), "Checking if the search button is not enabled");
	  //Assert.assertNull(object,message);
	  //Assert.assertNotNull(object,message);
	  App().Pages().HomePage().clickSearchButton();;
	  Thread.sleep(2000);
	  
	  String expectedUrl="https://www.ebay.com/n/all-categories";
	  String expectedTitle="Shop by Category | eBay";
	  
	  
	  String newUrl=App().Flow().getCurrentPageUrl();
	  String newTitle= App().Flow().getCurrentPageTitle();
	  System.out.println(newUrl);
	  System.out.println(newTitle);
	  
	  Assert.assertEquals(newUrl, expectedUrl,"verifing whether the expected and attained url are same");
	  Assert.assertEquals(newTitle, expectedTitle,"verifing whether the expected and attained title are same");
	  //Assert.assertNotEquals(newUrl, expectedUrl,"verifing whether the expected and attained url are not same");
	  //Assert.assertNotEquals(newTitle, expectedTitle,"verifing whether the expected and attained title are not same");
	  
	  
	  
	  
	  
  }
  
  
  @Test(groups= {"P2","P3"})
  public void softAsserts() throws Exception{
	  
	  App().Flow().navigateToUrl(App().Pages().HomePage().getPageUrl());
	  
	  SoftAssert sa=new SoftAssert();
	  sa.assertTrue(App().Pages().HomePage().isSearchButtonEnabled(), "Checking if the search button is enabled");
	  //sa.assertFalse(homePageElements.searchBtn.isEnabled(), "Checking if the search button is not enabled");
	  //sa.assertNull(object,message);
	  //sa.assertNotNull(object,message);
	  App().Pages().HomePage().clickSearchButton();
	  
	  String expectedUrl="https://www.ebay.com/n/all-categories";
	  String expectedTitle="Shop by Category | eBay";
	  
	  
	  String newUrl=App().Flow().getCurrentPageUrl();
	  String newTitle= App().Flow().getCurrentPageTitle();
	  System.out.println(newUrl);
	  System.out.println(newTitle);
	  
	  sa.assertEquals(newUrl, expectedUrl,"verifing whether the expected and attained url are same");
	  sa.assertEquals(newTitle, expectedTitle,"verifing whether the expected and attained title are same");
	  //sa.assertNotEquals(newUrl, expectedUrl,"verifing whether the expected and attained url are not same");
	  //sa.assertNotEquals(newTitle, expectedTitle,"verifing whether the expected and attained title are not same");
	  
	  
	  sa.assertAll();

}
}

package com.dezlearn.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Ebay_Advanced_Search_Sanity extends AbstractBaseTest {
		
	  @Test(groups= {"P0","P1"})
	  public void empty_search_test_Asserts() throws Exception{
		  
		  App().Flow().navigateToUrl(App().Pages().AdvSearchPage().getPageUrl());
		  
		  Assert.assertTrue(App().Pages().AdvSearchPage().isAdvSearchButtonEnabled(), "Checking if the search button is enabled");
		  //Assert.assertFalse(searchButton.isEnabled(), "Checking if the search button is not enabled");
		  //Assert.assertNull(object,message);
		  //Assert.assertNotNull(object,message);
		  App().Pages().AdvSearchPage().clickAdvSearchButton();
		  
		  String expectedUrl="https://www.ebay.com/n/all-categories";
		  String expectedTitle="Shop by Category | eBay";
		  
		  
		  String newUrl=App().Flow().getCurrentPageUrl();
		  String newTitle= App().Flow().getCurrentPageTitle();
		  System.out.println(newUrl);
		  System.out.println(newTitle);
		  
		  Assert.assertEquals(newUrl, expectedUrl,"verifing whether the expected and attained url are same");
		  Assert.assertEquals(newTitle, expectedTitle,"verifing whether the expected and attained title are same");
		  //Assert.assertNotEquals(newUrl, expectedUrl,"verifing whether the expected and attained url are not same");
		  //Assert.assertNotEquals(newTitle, expectedTitle,"verifing whether the expected and attained title are not same");
		  
	  }
	  @Test(groups= {"P2","P1"})
	  public void category_options_in_ascending_order_test() throws Exception {
		  
		  App().Flow().navigateToUrl(App().Pages().AdvSearchPage().getPageUrl());
		  
		  List<WebElement> category_options = App().Pages().AdvSearchPage().getAllCatOptions();
		  List<String> arr1= new ArrayList<>();
		  
		  for (WebElement option:category_options)
		  {
			  arr1.add(option.getText());
		  }
		  List<String> arr2= new ArrayList<>(arr1);
		  Collections.sort(arr2);
		  
		 System.out.println("Actual List: "+arr1);
		 System.out.println("Sorted List: "+arr2);
		 Assert.assertEquals(arr1, arr2,"Verifying the list is in ascending order");
	  }
	  
	  @Test(groups= {"P0"})
	  public void ebay_logo_link_navigates_home_page_test() throws Exception{
		  
		  App().Flow().navigateToUrl(App().Pages().AdvSearchPage().getPageUrl());
		  
		  String expectedURL="https://www.ebay.com/";
		  String expectedTitle="Electronics, Cars, Fashion, Collectibles & More | eBay";
		  
		  App().Pages().AdvSearchPage().clickOnEbayLogo();;
		  Thread.sleep(2000);
		  String newUrl=App().Flow().getCurrentPageUrl();
		  String newTitle= App().Flow().getCurrentPageTitle();
		  Assert.assertEquals(newUrl,expectedURL,"Verify URL of the new page");
		  Assert.assertEquals(newTitle,expectedTitle,"Verify Title of the new page");
		  
	  }
	  
	  
	  @Test(groups= {"P3","P1"})
	  public void advanced_search_keywords_test() throws Exception{
		  
		  App().Flow().navigateToUrl(App().Pages().AdvSearchPage().getPageUrl());
		  
		  String keyword1="unlocked";
		  String keyword2="ios";
		  String searchString= keyword1+" "+keyword2;
		  App().Pages().AdvSearchPage().enterSearchStringInKeywordsField(searchString);
		  App().Pages().AdvSearchPage().clickAdvSearchButton();;
		  Thread.sleep(2000);
		  
		 
		  String firstResultTitle=App().Pages().SearchResultsPage().getFirstResultTItle();
		  
		  Assert.assertTrue(firstResultTitle.toLowerCase().contains(keyword1),"Result Title Contains First Keyword "+ keyword1);
		  Assert.assertTrue(firstResultTitle.toLowerCase().contains(keyword2),"Result Title Contains Second Keyword "+ keyword2);
		  
	  }
	  
}

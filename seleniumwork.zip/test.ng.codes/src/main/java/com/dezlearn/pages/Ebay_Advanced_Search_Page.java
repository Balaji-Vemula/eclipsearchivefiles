package com.dezlearn.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.dezlearn.elements.Ebay_Advanced_Search_Page_Elements;

public class Ebay_Advanced_Search_Page {
	
	WebDriver driver;
	String pageUrl="https://www.ebay.com/sch/ebayadvsearch";
	Ebay_Advanced_Search_Page_Elements advSearchElements;
	
	public Ebay_Advanced_Search_Page(WebDriver driver) {
		this.driver=driver;
		advSearchElements=new Ebay_Advanced_Search_Page_Elements(driver);
	}
	
	/*
	 * Is advanced search button is enabled
	 */
	public boolean isAdvSearchButtonEnabled() {
		return advSearchElements.advSearchBtn.isEnabled();
	}
	
	/*
	 * Click on Advanced SearchButton
	 */
	public void clickAdvSearchButton() {
		advSearchElements.advSearchBtn.click();
	}
	/*
	 * Get all catagory dropdown options
	 */
	public List<WebElement> getAllCatOptions(){
		return advSearchElements.allCatSelectBoxOptions;
	}
	/*
	 * Click on logo
	 */
	public void clickOnEbayLogo() {
		advSearchElements.ebayLogo.click();
	}
	/*
	 * Enter search string in keywords field
	 */
	public void enterSearchStringInKeywordsField(String srcSring) {
		advSearchElements.keywordsField.sendKeys(srcSring);
	}
	/*
	 * Get page URL
	 */
	public String getPageUrl()
	{
		return pageUrl;
	}
}

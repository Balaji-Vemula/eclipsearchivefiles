public class RegEX_Generalized_NumberRanges {

	public static void main(String[] args) {
		
		/*
		 * Create a RegEx pattern to represent following number ranges
		 * 1. 0-99     ------>    "[0-9][0-9]?"
		 * 2. 0-1000   ------>    "[0-9][0-9]?[0-9]?|1000"
		 * 3. 99-9999  ------>    "99|[1-9][0-9][0-9][0-9]?"
		 * 4. 25-75    ------>    "2[5-9]|[3-6][0-9]|7[0-5]"
		 * 5. 220-240  ------>    "2[2-3][0-9]|240"
		 */
		
		String patt = "2[2-3][0-9]|240";
		
		String str1 = "100";
		
		System.out.println(str1.matches(patt));
		
	}

}

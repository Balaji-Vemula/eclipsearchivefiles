 
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class File_Copy_Rename {

	public static void main(String[] args) throws IOException {
		
		/*
		 * 1. Copy contents of one file to another
		 * 2. Copy a file to directory
		 * 3. Rename / Move a file
		 */
		
		File file = new File("C:\\Users\\Balaji Vemula\\Desktop\\File.txt");
		File file1 = new File("C:\\Users\\Balaji Vemula\\Desktop\\File1.txt");
		File dir = new File("C:\\Users\\Balaji Vemula\\Desktop\\Folder");
		File file2 = new File("C:\\Users\\Balaji Vemula\\Desktop\\File2.txt");//This file is used to rename so
		// this file of name File2.txt should not be exist in that directory Only then the rename occurs
		//for rename we use FileUtils.moveFile(file,new_name_file)
		
		FileUtils.copyFile(file, file1);
		FileUtils.copyFileToDirectory(file1, dir);
		FileUtils.moveFile(file, file2);//It just renames not moves and the rename file should not exist
		
		
	}
}

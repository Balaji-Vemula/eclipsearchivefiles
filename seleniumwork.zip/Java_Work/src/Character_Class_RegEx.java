public class Character_Class_RegEx {

	public static void main(String[] args) {
		
		/*
		 * 1. \d - matches a single digit character
		 * 2. \w - matches a single word character
		 * 3. \s - matches a single whitespace character
		 * 4. \D - matches a single non-digit character
		 * 5. \W - matches a single non-digit and non-word character
		 */
		
		
		String patt = "\\d";
		
		String str1 = "s";
		
		System.out.println(str1.matches(patt));
		
	}

}

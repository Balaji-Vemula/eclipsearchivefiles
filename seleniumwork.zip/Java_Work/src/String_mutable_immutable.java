
public class String_mutable_immutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * StringBuilder class is used to create mutable (modifiable) string
		 * Some useful methods:
		 * append, insert, replace, delete, reverse
		 */
		
		String str1 = "I";
		
		str1 = str1 + " Like";
		
		str1 = str1 + " Java";
		
		System.out.println(str1);
		
		//I / Like / I like / Java / I like Java
		
		StringBuilder sb2 = new StringBuilder("I");
		
		sb2.append(" Like");
		sb2.append(" Java");
		
		System.out.println(sb2);
		
		/*
		 * Some useful methods from StringBuilder 
		 * insert, replace, delete, reverse
		 */
		StringBuilder sb1 = new StringBuilder("Learning is fun");
		
		sb1.insert(9, "Java ");
		
		System.out.println(sb1);
		
		sb1.replace(9, 13, "Everything");
		
		System.out.println(sb1);
		
		sb1.deleteCharAt(0);
		
		System.out.println(sb1);
		
		sb1.delete(2, 10);
		
		System.out.println(sb1);
		
		sb1.reverse();
		
		System.out.println(sb1);
	}

}

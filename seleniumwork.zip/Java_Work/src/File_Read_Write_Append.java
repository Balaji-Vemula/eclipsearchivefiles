
import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

public class File_Read_Write_Append {

	public static void main(String[] args) throws IOException {

		/*
		 * Working with Text Files using Apache Commons IO
		 * 
		 * 1. Download Apache Commons IO from:
		 * https://commons.apache.org/proper/commons-io/download_io.cgi 2. Add Commons
		 * IO jar files to Java Build Path 3. Use FileUtils from commons-io to read a
		 * text file
		 */

		File file = new File("C:\\Users\\Balaji Vemula\\Desktop\\File.txt");
		
		String x="One day, king Akbar asked a question in his court that left everyone in the courtroom puzzled. As they all tried to figure out the answer, Birbal walked in and asked what the matter was. They repeated the question to him.\r\n" + 
				"\r\n" + 
				"The question was, �How many crows are there in the city?�\r\n" + 
				"\r\n"+  
				"Birbal immediately smiled and went up to Akbar. He announced the answer; he said there were twenty-one thousand, five hundred and twenty-three crows in the city. When asked how he knew the answer, Birbal replied, �Ask your men to count the number of crows. If there are more, then the relatives of the crows must be visiting them from nearby cities. If there are fewer, then the crows from our city must be visiting their relatives who live outside the city.� Pleased with the answer, Akbar presented Birbal with a ruby and pearl chain.";
		FileUtils.write(file, x, "UTF-8", false);// False indicates to overwrite the text in the file to string x
		
		
		String y = FileUtils.readFileToString(file, "UTF-8");

		System.out.println(y);
		
		String text="\n\nThis is a amazing story";
		
		FileUtils.write(file, text, "UTF-8", true);//True indicates add the string text to the text already present in the file
		
		
		String z = FileUtils.readFileToString(file, "UTF-8");

		System.out.println(z);
		
		String anotherStory="A lion was once sleeping in the jungle when a mouse started running up and down his body just for fun. This disturbed the lion�s sleep, and he woke up quite angry. He was about to eat the mouse when the mouse desperately requested the lion to set him free. �I promise you, I will be of great help to you someday if you save me.� The lion laughed at the mouse�s confidence and let him go.\r\n" + 
				"\r\n" + 
				"One day, a few hunters came into the forest and took the lion with them. They tied him up against a tree. The lion was struggling to get out and started to whimper. Soon, the mouse walked past and noticed the lion in trouble. Quickly, he ran and gnawed on the ropes to set the lion free. Both of them sped off into the jungle.";
		
		FileUtils.write(file,anotherStory, "UTF-8", false);// False indicates to overwrite the text in the file to string x
		
		
		String overWrittenContent = FileUtils.readFileToString(file, "UTF-8");

		System.out.println(overWrittenContent);

	}

}
